/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cricketstatisticsmanager;

/**
 * CricketRunsScored Class
 
 */
public class CricketRunsScored extends Cricket {
    
    /**
     * Constructor with parameters - calls superclass constructor
     * @param batsman The batsman's name
     * @param stadium The stadium name
     * @param runs Total runs scored
     */
    public CricketRunsScored(String batsman, String stadium, int runs) {
        super(batsman, stadium, runs);
    }
    
    /**
     * Implements the printReport method to display batsman statistics
     * Format matches the sample screenshot exactly
     */
    @Override
    public void printReport() {
        System.out.println("\nBATSMAN RUNS SCORED REPORT");
        System.out.println("**************************");
        System.out.println("CRICKET PLAYER: " + getBatsman());
        System.out.println("STADIUM: " + getStadium());
        System.out.println("TOTAL RUNS SCORED: " + getRunsScored());
        System.out.println("**************************");
    }
}