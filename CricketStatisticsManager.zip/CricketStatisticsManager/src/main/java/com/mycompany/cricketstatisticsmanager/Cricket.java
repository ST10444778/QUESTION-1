/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cricketstatisticsmanager;

/**
 * Abstract Cricket Class
 * 
 *
 */
public abstract class Cricket implements iCricket {
    // Private variables to store data
    private final String batsmanName;
    private final String stadiumName;
    private final int totalRuns;
    
    /**
     * Constructor with parameters
     * @param batsman The batsman's name
     * @param stadium The stadium name
     * @param runs Total runs scored
     */
    public Cricket(String batsman, String stadium, int runs) {
        this.batsmanName = batsman;
        this.stadiumName = stadium;
        this.totalRuns = runs;
    }
    
    /**
     * Returns the batsman's name
     * @return batsman name
     */
    @Override
    public String getBatsman() {
        return batsmanName;
    }
    
    /**
     * Returns the stadium name
     * @return stadium name
     */
    @Override
    public String getStadium() {
        return stadiumName;
    }
    
    /**
     * Returns total runs scored
     * @return total runs
     */
    @Override
    public int getRunsScored() {
        return totalRuns;
    }
    
    /**
     * Abstract method to print report - must be implemented by subclasses
     */
    public abstract void printReport();
}
