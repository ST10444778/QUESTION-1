/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cricketstatisticsmanager;
import java.util.Scanner;

/**
 * RunApplication Class
 * Main class to demonstrate the cricket application with user input
 * 
 * @author Student Name
 * @version 1.0
 */
public class RunApplication {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // Get user input - matching exact wording from sample
        System.out.print("The cricketer name: ");
        String batsmanName = input.nextLine();
        
        System.out.print("Enter the stadium: ");
        String stadiumName = input.nextLine();
        
        System.out.print("Enter the total runs scored by " + batsmanName + 
                        " at " + stadiumName + ": ");
        int runsScored = input.nextInt();
        
        // Create CricketRunsScored object using parameterized constructor
        CricketRunsScored playerStats = new CricketRunsScored(batsmanName, stadiumName, runsScored);
        
        // Display the report using the printReport method
        playerStats.printReport();
        
        input.close();
    }
}
