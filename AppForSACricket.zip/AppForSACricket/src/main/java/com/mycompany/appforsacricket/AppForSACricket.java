/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.appforsacricket;

import java.util.Scanner;

public class AppForSACricket {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        String[] stadiums = {"KINGSMEAD", "ST GEORGES", "WANDERERS"};
        String[] batsmen = {"Jacques Kallis", "Hashim Amla", "AB de Villiers"};
        int[][] runs = new int[3][3];
        
        System.out.println("SA CRICKETER APPLICATION");
        System.out.println("------------------------\n");
        
        // INPUT - Match exact wording from sample
        for (int i = 0; i < stadiums.length; i++) {
            for (int j = 0; j < batsmen.length; j++) {
                System.out.print("Enter the number runs scored by " + batsmen[j] + 
                               " at " + stadiums[i] + ": ");
                runs[i][j] = input.nextInt();
            }
            System.out.println();
        }
        
        // REPORT - Match exact format from sample
        System.out.println("RUNS SCORED REPORT");
        System.out.println("==================\n");
        
        for (int j = 0; j < batsmen.length; j++) {
            System.out.println(batsmen[j] + " runs scored:");
            for (int i = 0; i < stadiums.length; i++) {
                System.out.println("  - At " + stadiums[i] + ": " + runs[i][j]);
            }
            System.out.println();
        }
        
        // TOTALS - Match exact format from sample
        System.out.println("TOTAL RUNS AT STADIUMS");
        System.out.println("======================\n");
        
        int maxRuns = 0;
        String topStadium = "";
        
        for (int i = 0; i < stadiums.length; i++) {
            int total = 0;
            for (int j = 0; j < runs[i].length; j++) {
                total += runs[i][j];
            }
            
            if (total > maxRuns) {
                maxRuns = total;
                topStadium = stadiums[i];
            }
            
            System.out.println(stadiums[i] + "\t" + total);
        }
        
        System.out.println("\nSTADIUM WITH THE MOST RUNS: " + topStadium);
        
        input.close();
    }
}